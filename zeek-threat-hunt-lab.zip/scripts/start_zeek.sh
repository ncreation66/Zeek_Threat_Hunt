#!/bin/bash
# start_zeek.sh - Runs Zeek on the given PCAP and outputs logs to /logs

PCAP_FILE=$1

if [ -z "$PCAP_FILE" ]; then
    echo "Usage: $0 <pcap_file>"
    exit 1
fi

mkdir -p logs
zeek -r "$PCAP_FILE" LogAscii::use_json=T
echo "Zeek analysis complete. Logs stored in /logs"
