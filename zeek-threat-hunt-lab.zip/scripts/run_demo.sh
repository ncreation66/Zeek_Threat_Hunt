#!/bin/bash
PCAP=$1
if [ -z "$PCAP" ]; then
  echo "Usage: $0 <pcap-file>"
  exit 1
fi

LOGS_DIR="logs"
mkdir -p $LOGS_DIR

echo "[*] Running Zeek on $PCAP ..."
zeek -C -r "$PCAP" local "Log::default_writer=Log::WRITER_ASCII" LogAscii::use_json=T
mv *.log $LOGS_DIR 2>/dev/null

echo "[*] Logs saved in $LOGS_DIR"
