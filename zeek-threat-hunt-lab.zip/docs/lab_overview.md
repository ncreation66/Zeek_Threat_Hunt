# Lab Overview
This lab contains sanitized packet captures simulating benign and suspicious activity.
You can use Zeek to extract HTTP, DNS, and SSL logs and then hunt for anomalies.
