#!/bin/bash
LOGS_DIR="logs"

echo "[*] Searching logs for suspicious activity..."
grep -i "malware" $LOGS_DIR/*.log || echo "No malware indicators found."
grep -i "dns" $LOGS_DIR/*.log || echo "No suspicious DNS found."
