# Zeek Threat Hunt Lab

## Overview
This is a self-contained Zeek lab for practicing network threat hunting using **sanitized test traffic**.

## Prerequisites
- Zeek installed and in your PATH
- Bash shell (Linux/Mac)
- unzip utility

## Setup
```bash
git clone <your-repo-url>.git
cd zeek-threat-hunt-lab
```

## Running the Lab
```bash
# Run Zeek on example PCAP
./scripts/run_demo.sh pcaps/web_traffic.pcap

# Parse logs for key findings
./scripts/parse_logs.sh
```

## Output
All logs will appear in `logs/`.

## License
MIT
